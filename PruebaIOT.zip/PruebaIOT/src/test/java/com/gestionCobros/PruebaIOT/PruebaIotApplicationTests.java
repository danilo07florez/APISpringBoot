package com.gestionCobros.PruebaIOT;

import org.junit.jupiter.api.Test;
import org.springframework.boot.test.context.SpringBootTest;

@SpringBootTest
class PruebaIotApplicationTests {

	@Test
	void contextLoads() {
	}

}
