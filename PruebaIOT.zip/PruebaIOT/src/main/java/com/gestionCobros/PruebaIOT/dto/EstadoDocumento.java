package com.gestionCobros.PruebaIOT.dto;

public enum EstadoDocumento {
    PENDIENTE, PAGADO, VENCIDO, CEDIDO;
}
